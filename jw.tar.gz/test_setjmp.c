#include <stdio.h>
#include <string.h>

#include <setjmp.h>

int total;
jmp_buf env;
jmp_buf env1;

int
test_setjmp(jmp_buf buf)
{
    int rc;
    rc = setjmp(buf);
    if (rc == 0) {
        printf("return 1st from setjmp\n");
    } else {
        printf("return 2nd from setjmp %d\n", rc);
    }
    return rc;
}

int
test_a(int i)
{
    int rc;
    if(i == 0) {
        longjmp(env, 0xff);
        return 0;
    } else {
        if (i == 2) {
            rc = test_setjmp(env1);
            if (rc != 0) {
                return test_a(0);
            }
        } else if (i==1) {
            longjmp(env1, 0xffff);
        }
        return i+test_a(i-1);
    }
}

int
main()
{
    int i=10;
    int rc;

    rc = test_setjmp(env);
    if (rc == 0) {
        printf("start testing...\n");
    } else {
        printf("longjmp return, total = %d\n", total);
        return 0;
    }
    total = test_a(i);
    printf("stop testing... total = %d\n", total);
    return total;
}
