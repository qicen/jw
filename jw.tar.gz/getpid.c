#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>

int
main()
{
    int i = 0;

    __asm__ volatile(
        "movl $39, %%eax\n\t"
        "int $0x80\n\t"
        "movl %%eax, %0\n\t"
        : "=m" (i)
    );
    if (i<0) {
        printf("error msg %s\n", strerror(i));
    }
#if 0
    i = getpid();
#endif
    printf("the process is %d\n", i);
    return 0;
}
