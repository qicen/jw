#include<stdio.h>

void main()
{
    int a[10];
    int *m = a;
    void **n = (void **)a;

    m++;
    n++;
    printf("a = %x, m = %x, n = %x\n", a, m, n);
    return;
}

