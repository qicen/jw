#include <stdio.h>
#include <stdlib.h>

#include <sys/time.h>
#include <string.h>

char sql_str[256] = "select application, count(application) from (select application from report_session1_attached.data7_8 where timestamp >= 1568125222  ) ReportUnionTbl 1568125222 group by application having count(application)>1568125222;";

extern int
str_replace(int new_time, int old_time);
int
str_replace(int new_time, int old_time)
{
    char *bp;
    char old_time_str[12];
    char new_time_str[12];
    char *tmp;
    int i, n=0;

    snprintf(new_time_str, sizeof(new_time_str), "%-10d", new_time);
    snprintf(old_time_str, sizeof(old_time_str), "%d", old_time);
    bp = sql_str;
    tmp = strstr(bp, old_time_str);
    if (!tmp) {
        return -1;
    }
    while(tmp) {
        n++;
        for (i=0; i<sizeof(new_time_str) && new_time_str[i]!= '\0'; i++) {
            *tmp = new_time_str[i];
            tmp++;
        }
        tmp = strstr(tmp, old_time_str);
    }
    return n;
}

int 
main(int argc, char *argv[])
{
    int rc;

    rc = str_replace(123, 1568125222);
    printf("return code:%d, sql: %s\n", rc, sql_str);
    rc = str_replace(4294967295, 123);
    printf("return code:%d, sql: %s\n", rc, sql_str);
    rc = str_replace(12345, 4294967295);
    printf("return code:%d, sql: %s\n", rc, sql_str);
    rc = str_replace(12345, 4294967295);
    printf("return code:%d, sql: %s\n", rc, sql_str);

    return 0;
}
