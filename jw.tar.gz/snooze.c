#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <limits.h>
#include <errno.h>
#include <stdio.h>

int snooze(int sec)
{
    int i;
    i = sleep(sec);
    printf("sleep for %d of %d secs\n", sec-i, sec);
    return i;
}

void sig_int(int sig)
{
    printf("Caught ctrl-c\n");
    return;
}

int main(int argc, char *argv[])
{
    int sec = 0;
    
    if (argc != 2) {
        printf("please type in the command like %s <number>\n", argv[0]);
        return -1;
    }
    errno = 0;
    sec = strtoul(argv[1], NULL, 10);
    if (errno == ERANGE && (sec == 0 || sec == ULONG_MAX)) {
        printf("please type in the correct range (0-%u)\n", ULONG_MAX);
        return -2;
    } else if (errno != 0) {
        printf("please type in a number\n");
        return -3;
    }
    
    if(signal(SIGINT, sig_int) == SIG_ERR) {
        printf("install signal failed!\n");
        return -4;
    }
    snooze(sec);
    return 0;
}
