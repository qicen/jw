#include <stdio.h>

int main()
{
    double a = 6.0;
    int b = 666;

    printf("a is %lx!\n", a);
    printf("%d10", b);

    return 0;
}
