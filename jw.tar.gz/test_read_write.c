#include <stdio.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <errno.h>
#include <string.h>

static int
test_read(int fd)
{
    int rc, i;
    char buf[16];

    rc = read(fd, &buf, sizeof(buf));
    if (rc <= 0) {
        printf("read failed %d: %d/%s\n", rc, errno, strerror(errno));
        return -1;
    }
    for (i=0;i<sizeof(buf);i++) {
        printf("%x ", (int)buf[i]);
    }
    printf("\n");
    return 0;
}

static int
test_write(int fd)
{
    return 0;
}

int main(int argc, char *argv[])
{
    int fd, i;
    char *filename = argv[1];

    fd = open(filename, O_CREAT|O_RDWR);
    if (fd == -1) {
        printf("open %s failed: %d/%s\n", filename, errno, strerror(errno));
        return -1;
    }

    for (i=0;i<2;i++)
        test_read(fd);
    test_write(fd);
    close(fd);
    return 0;
}
