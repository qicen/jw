#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include "stdio.h"

void alarm_handler(int sig)
{
    static int beep = 5;

    if (beep>0) {
        printf("BEEP!\n");
        alarm(1);
        beep--;
    } else {
        printf("BOOM!!!\n");
        exit(0);
    }
}

int main(void)
{
    int i = 0;
    signal(SIGALRM, alarm_handler);
    alarm(1);

    while(1) {
        printf("enter %d", i++);
        pause();
    }
    exit(0);
}
