int *orig_stack_pointer;
int global_argu;

int break_stack(void);
int break_stack() {
    break_stack();
}

int main()
{
    __asm__("movl %esp, orig_stack_pointer");

    break_stack();
    return 0;
}
