#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct {
    short id;
    short table;
    int pad;
} id_to_table_t;

static id_to_table_t id_2_table[] =
{
    {1, 2, 111},
    {2, 3, 222},
    {3, 4, 333},
    {4, 5, 444},
    {5, 6, 555},
};

id_to_table_t *g_p;

int
main(int argc, char *argv[])
{
    int i;
    int a = sizeof(id_2_table);

    int b = sizeof(id_2_table)/sizeof(id_to_table_t);

    printf("%d %d\n", a, b);

    g_p = malloc(sizeof(id_to_table_t)*4);
    for (i=0; i<4; i++) {
        g_p[i].id = i;
        g_p[i].table = i+1;
        g_p[i].pad = i-1;
    }
    printf("g_p[3] id: %d, table: %d, pad: %d", g_p[3].id, g_p[3].table, g_p[3].pad);

    return 0;
}
