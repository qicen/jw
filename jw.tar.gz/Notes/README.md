# Notes
the common commands used.

@20200728 add some kubernetes words.
