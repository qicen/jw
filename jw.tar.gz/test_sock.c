#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <errno.h>
#include <string.h>
#include <signal.h>

#include <sys/select.h>

char *optstring = "cs";

typedef enum {
    SERVER = 0,
    CLIENT,
    UNKNOWN
}open_type;

int server_port = 6699;
int client_conn;
#define MSG_SIZE 64

void
sig_handler_client(int sig)
{
    int rc;

    switch(sig) {
        case SIGPIPE:
            printf("catch sigpipe, server may close the connection, exit\n");
            exit(1);
        case SIGINT:
            printf("catch sigint, close the connection to server\n");
            rc = shutdown(client_conn, SHUT_RDWR);
            if (rc == -1) {
                printf("shutdown failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
            }
            exit(2);
        default:
            printf("catch sig %d\n");
            break;
    }
}

static void 
init_client()
{
    struct sigaction sa;
    int rc;

    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sa.sa_handler = sig_handler_client;
    rc = sigaction(SIGPIPE, &sa, NULL);
    if (rc == -1) {
        printf("sigaction SIGPIPE failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
        exit(2);
    }

    rc = sigaction(SIGINT, &sa, NULL);
    if (rc == -1) {
        printf("sigaction SIGINT failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
        exit(3);
    }
}


static int
process_client(char *host)
{
    int client = -1;
    int rc;
    struct sockaddr_in sock_in;
    struct sockaddr *addr;
    char msg[MSG_SIZE];

    client = socket(AF_INET, SOCK_STREAM, 0);
    if (client == -1) {
        printf("socket failed: client=%d, errno=%d/%s\n", client, errno, strerror(errno));
        return -2;
    }

    memset(&sock_in, 0, sizeof(sock_in));
    //sock_in.sin_len = sizeof(struct sockaddr_in);
    sock_in.sin_family = AF_INET;
    sock_in.sin_port = htons(server_port);
    inet_aton(host, &(sock_in.sin_addr));
    addr = (struct sockaddr *)(&sock_in);

    rc = connect(client, addr, sizeof(struct sockaddr_in));
    if (rc == -1) {
        printf("connect failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
        return -3;
    }
    client_conn = client;
    printf("connect ok, please input command:\n");
    while(1) {
        fgets(msg, sizeof(msg), stdin);
        if (msg[0] != '\n') {
            msg[strlen(msg)-1] = '\0';
            rc = send(client, msg, strlen(msg), 0);
            if (rc == -1) {
                printf("send failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
                continue;
            }
            if (strcmp(msg, "bye") == 0) {
                printf("user input bye!\n");
                rc = shutdown(client, SHUT_RDWR);
                if (rc == -1) {
                    printf("shutdown failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
                }
                break;
            }
        }
        printf("please input command:\n");
    }
    return 0;
}

void
sig_handler_server(int sig)
{
    switch(sig) {
        case SIGINT:
            printf("catch sigint, close the server\n");
            exit(2);
        default:
            printf("catch sig %d\n");
            break;
    }
}

static void
init_server()
{
    int rc;
    struct sigaction sa;

    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sa.sa_handler = sig_handler_server;
    rc = sigaction(SIGINT, &sa, NULL);
    if (rc == -1) {
        printf("sigaction SIGINT failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
        exit(3);
    }
}
static int 
process_server()
{
    int server = -1;
    int rc, len;
    struct sockaddr addr;
    struct sockaddr_in sin;
    fd_set readfds;
    int i, client_max, client_new, client_num  = 0;
    char msg[MSG_SIZE];

    server = socket(AF_INET, SOCK_STREAM, 0);
    if (server == -1) {
        printf("create socket failed\n");
        return -2;
    }

    len = 1;
    rc = setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &len, sizeof(len));
    if (rc == -1) {
        printf("setsockopt failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
        return -9;
    }

    bzero(&sin, sizeof(sin));
    //sin.sin_len = sizeof(sin);
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = htonl(0x7f000001);
    sin.sin_port = htons(server_port);
    memcpy(&addr, &sin, sizeof(addr));

    rc = bind(server, &addr, sizeof(addr));
    if (rc != 0) {
        printf("bind failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
        return -3;
    }

    rc = listen(server, 5);
    if (rc != 0) {
        printf("listen failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
        return -4;
    }

    printf("%s: start server\n", __FUNCTION__);

    client_max = server;
    len = sizeof(addr);
    while (1) {
        FD_ZERO(&readfds);
        for (i=server; i<=client_max; i++)
            FD_SET(i, &readfds);
        rc = select(client_max+1, &readfds, NULL, NULL, NULL);
        if (rc == -1) {
            printf("select failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
            return -4;
        } else if (rc == 0) {
            printf("select timeout: rc=%d\n", rc);
            continue;
        } else {
            client_new = 0;
            if (FD_ISSET(server, &readfds)) {
                client_new = accept(server, &addr, &len);
                if (client_new == -1) {
                    printf("accept failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
                } else {
                    printf("accept new client 0x%x:%d, client_new %d, client_max %d, client_num %d\n", ntohl((unsigned int)(((struct sockaddr_in *)&addr)->sin_addr.s_addr)), 
                            (unsigned short)(((struct sockaddr_in *)&addr)->sin_port), client_new, client_max, client_num);
                    client_num ++;
                }
            }
                
            for (i=client_max; i>server; i--){
                msg[0] = '\0'; 
#if 0
                if (FD_ISSET(i, &readfds)) {
                    rc = recv(i, msg, sizeof(msg), 0);
                    if (rc == -1) {
                        printf("recv failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
                    } else if (rc > 0) {
                        msg[rc] = '\0';
                        printf("recv from %d: %d:%s\n", i, rc, msg);
                    }
                    if ((rc == 0) ||
                        (strcmp(msg, "bye") == 0)) {
                        printf("recv %s, close client %d\n", (rc==0)?"shutdown":"bye", i);
                        rc = shutdown(i, SHUT_RDWR);
                        if (rc == -1) {
                            printf("shutdown failed: rc=%d, errno=%d/%s\n", rc, errno, strerror(errno));
                        }
                        if (i == client_max) {
                            client_max = i-1;
                            if (close(i) == -1) {
                                printf("close failed\n");
                            }
                        }
                        client_num --;
                    }
                }
#endif
            }

            if (client_new > client_max)
                client_max = client_new;
        }
    }

    return rc;
}

int 
main(int argc, char *argv[])
{
    int opt = -1;
    int is_client = -1;
    char *host;
    while((opt = getopt(argc, argv, optstring)) != -1) {
        switch(opt) {
            case 'c':
                printf("open client: \n");
                is_client = CLIENT;
                break;
            case 's':
                printf("open server: \n");
                is_client = SERVER;
                break;
            case '?':
                printf("optarg %s, optind %d, opterr %d, optopt %d\n", optarg, optind, opterr, optopt);
                break;
            default:
                printf("unknow option %c\n", opt);
                exit(-1);
        }
    }

    if (is_client == CLIENT) {
        if (argc != optind+1) {
            printf("wrong destination!!\n");
        } else {
            host = argv[optind];
            printf("\tconnecting to server: %s\n", host);
            init_client();
            process_client(host);
        }
    } else if (is_client == SERVER) {
        process_server();
    }

    return 0;
}
