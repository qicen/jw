#ifndef __TEST_CACHE_LINE_H__
#define __TEST_CACHE_LINE_H__

typedef struct test_cache_line_struct_ {
    char __attribute__ ((aligned(64))) a;
    short __attribute__ ((aligned(64))) b;
    int c;
    long long d;
}__attribute__ ((aligned(64))) test_cache_line_struct;



#endif
