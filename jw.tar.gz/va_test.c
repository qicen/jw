#include <stdarg.h>
#include <stdio.h>
#include <string.h>

static int test_va(char *title, ...)
{
    
}
