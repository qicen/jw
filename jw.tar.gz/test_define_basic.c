#include <stdio.h>
#include <stdlib.h>
#include "test_define_basic.h"

int
main()
{
    alert_ent_t alert;
    alert.i = 1;
    alert.a = 'a';
    alert.b = 15;
    alert.idx = sizeof((alert_basic_info));
    printf("%p %d\n", &alert, alert.idx);
    return 0;
}
