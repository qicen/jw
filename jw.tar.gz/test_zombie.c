#include <stdio.h>

#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

#if 0
int main(int argc, char *argv[])
{
    int pid;

    printf("starting the parent process.\n");

    pid = fork();
    if (pid < 0) {
        printf("create child failed due to: %d-%s\n", errno, strerror(errno));
        return -1;
    } else if (pid == 0) {
        printf("I am child.\n");
        exit(0);
    } else {
        printf("I have created child successfully.\n");
        while(1) {
            sleep(10);
            printf("anything happen?\n");
        }
    }

    return 0;
}
#endif

extern int test_zombie(void);
int test_zombie()
{
    int pid;

    printf("starting the parent process.\n");

    pid = fork();
    if (pid < 0) {
        printf("create child failed due to: %d-%s\n", errno, strerror(errno));
        return -1;
    } else if (pid == 0) {
        printf("I am child.\n");
        exit(0);
    } else {
        printf("I have created child successfully.\n");
        while(1) {
            sleep(10);
            printf("anything happen?\n");
        }
    }

    return 0;
}
