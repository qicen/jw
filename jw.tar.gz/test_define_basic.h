#define alert_basic_info \
    int i; \
    char a; \
    short b 

typedef struct {
    alert_basic_info;
    int idx;
} alert_ent_t;
