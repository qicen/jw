#include "test_cache_line.h"

test_cache_line_struct aaa[32];
int main()
{
    aaa[0].a = 'a';
    aaa[0].b = 55;
    aaa[0].c = 0x12345678;
    aaa[0].d = 0x1234567812345678;
    return 0;
}
