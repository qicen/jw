#include <stdio.h>

#define DATA_SIZE 200*1024*1024
int data_random[DATA_SIZE] = {1};


int
main()
{
    int total, i;
    for (i=0; i<DATA_SIZE; i++) {
        total += data_random[i];
    }
    printf("all data were loaded.\n");
    getchar();
    return 0;
}
