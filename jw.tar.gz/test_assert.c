#include <stdio.h>
#include <stdlib.h>

#include <assert.h>


int main(){
    int i, j;
    i = 1;
    j = 2;
    printf("i+j=%d\n", i+j);
    assert(0);
    i = 3;
    j = 4;
    printf("once again, i+j=%d\n",i+j);
    return 0;
}
