#include <stdio.h>

int push_esp()
{
    int rc;

    __asm__("movq %%rsp, %%rax;"
         "pushq %%rsp;"
         "popq %%rcx;"
         "subq %%rcx, %%rax;"
         "movl %%eax, %0"
         :"=r" (rc)
         :
         :"%rax", "%rcx");
    return rc; 
}

extern int do_nothing(int rc);
int do_nothing(int rc)
{
    return rc;
}
int pop_esp()
{
    long a=11, b=99;
    int rc;

    /* without this it will core, due to no movq(%rbp, %rsp) before ret */
    /* seems it cannot find the push instruction in __asm__ code, it will consider %rsp==%rbp, hence only popq(%rbp) before ret */
    /* it can be fixed through 1>add __asm__ to movq(%rbp, %rsp) manually; 2>call a stub function to trigger %rsp!=%rbp */

    /* it cannot be optimized by -O1 or -O2 !!!!!!!!! */
    __asm__("pushq %1;"
        "pushq %2;"
        "movq %%rsp, %%rcx;"
        "popq %%rsp;"
        "movl %%esp, %0;"
        "movq %%rcx, %%rsp;"
        :"=r" (rc)
        :"r" (a), "r"(b)
        :"%rcx");
    __asm__("movq %%rbp, %%rsp;":::);
    return rc;
}

int main()
{
    int i, j;
    i = push_esp();
    j = pop_esp();
    do_nothing(i);

    printf("i=%d, j=%d\n", i, j);

    return 0;
}
