#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include "program.h"
#include <sys/wait.h>
#include <string.h>
#include <arpa/inet.h>

typedef struct {
    int _b:1;
    int _reserved:31;
}misc;

typedef struct aaa {
    int i;
    union {
        int a;
        misc _v;
    };
#define b _v._b
#define reserved _v._reserved
} aaa_t;

extern void handle_sig_(int);
void
handle_sig_(int sig_no)
{
    if (sig_no == SIGUSR1)
        printf("received SIGUSR1\n");
    else if (sig_no == SIGUSR2)
        printf("received SIGUSR2\n");
    else
        printf("received signal %d\n", sig_no);
    return;
}

enum zone_type {
    ZONE_DMA,
    ZONE_DMA32,
    ZONE_NORMAL,
    ZONE_HIGHMEM,
    ZONE_MOVABLE,
    __MAX_NR_ZONES
};

typedef struct pglist_data{
    char name[32];
    int i;
    enum zone_type classzone_idx;
    char *aaa;
}pg_data_t;
 
char *template = "I am a template";

#define TEST_MACRO(aaa) \
    do{\
        aaa = 1;\
    }while(0)


extern int test_zombie(void);
int main(int argc, char *argv[]) {
#if 0
    int pid = 0;
    int change = -1;

    int *a = malloc(sizeof(int));
    *a = sizeof("timestamp2");
    printf("a = 0x%x, *a = %d, &a = 0x%x\n", a, *a, &a);
    if (signal(SIGUSR1, handle_sig_) != SIG_ERR)
        printf("catch SIGUSR1 %s, %s, %s, %s, %s, %s, %s, %s\n", "A", "B", "C", "D", "E", "F", "g", "H");
    if (signal(SIGUSR2, handle_sig_) != SIG_ERR)
        printf("catch SIGUSR2");

    how_to_unfold();

    printf("change is %d!!\n");
    how_to_unfold1();
    printf("continue after static inline exit :)");
    pid = fork();
    if (pid<0) {
        pause();
    } else if (pid == 0){
        printf("I am the child!\n");
        for(;;)
            pause();
    } else {
        printf("wait pid %d\n", pid);
        change = waitpid(pid, NULL, 0);
        printf("waitpid return %d, errno %d:%s\n", change, errno, strerror(errno));
    }
#endif
    pg_data_t pg, pg2;
    aaa_t test;
    int i, k, x, y;
    char *bp;
    unsigned long long hehe;
    long long j;
    char *src_country = "Australia";
    char *dst_country = "COUNTRY_UNKNOWN";
    char temp[8] = "unknown";
#define ROUND_UP_TO 256
    strncpy(pg.name, "I am a pg_data_t!\n", sizeof(pg.name));
    pg.i = 1;
    pg.classzone_idx = 100;
    //test_zombie();
    printf("pg: name %s, i %d, classzone_idx %d\n", pg.name, pg.i, pg.classzone_idx);
    test.a = 100;
    printf("test.a = %d, test.b = %d\n", test.a, test.b?1:0);
    i = test.reserved;
    printf("test.reserved = %d\n", i);
    test.b = 1;
    i = test.b;
    printf("test.b = %d\n", i);

    printf("-----------------I am the split--------------------\n");
    bp = (char *)&pg2;
    bp += sizeof(pg2.name);
    *((int *)bp) = 4567;
    bp += sizeof(int);
    bp += sizeof(enum zone_type);
    *((char **)bp) = template;
    printf("pg2 0x%x i = %d, aaa = %s\n", &pg2, pg2.i, pg2.aaa);
    printf("bp 0x%x\n", bp);

    printf("0xff>>5=%d\n", 0xff>>5);

    hehe = 0xfffffffffffffffe;
    printf("hehe is %lld\n", hehe);
    hehe = (hehe+ROUND_UP_TO-1)&(~(ROUND_UP_TO-1));
    printf("\tround up to %d is %llu\n", ROUND_UP_TO, hehe);

    if (!strcasestr(src_country, temp) && strcasestr(dst_country, temp)) {
        printf("dir is in\n");
    } else if (strcasestr(src_country, temp) && !strcasestr(dst_country, temp)) {
        printf("dir is out\n");
    } else {
        printf("dir err\n");
    }

#ifndef TEST_MACRO
#define TEST_MACRO(aaa) \
    do{\
        aaa = 2;\
    }while(0)
#endif
    TEST_MACRO(i);
    printf("i = %d\n", i);

    x=1;
    k=((x) && (i>0))?i+1:i;
    printf("k = %d\n", k);

#define DB_COL_NAME_APP_ID "app_id"
    bp = "count(" DB_COL_NAME_APP_ID ")";
    printf("bp = %s", bp);

    y = 12345678;
    printf("y = %d, %d\n", htonl(y), y);

    printf("- is %d bytes long\n", sizeof("-"));

    return 0;
}
