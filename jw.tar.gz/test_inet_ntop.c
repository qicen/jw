#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include "program.h"
#include <sys/wait.h>
#include <string.h>
#include <arpa/inet.h>

void
main()
{
    unsigned long long ip_high, ip_low;
    char ipv6[16];
    char ipstr[128];

    ip_high = 0x180fe;
    ip_low  = 0x100000000000000;

    *((unsigned long long *)&ipv6[0]) = ip_high;
    *((unsigned long long *)&ipv6[8]) = ip_low;

    inet_ntop(AF_INET6, &ipv6, ipstr, 128);
    printf("ip is %s\n", ipstr);
}
