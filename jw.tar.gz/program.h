#ifndef __PROGRAM_H__
#define __PROGRAM_H__

static inline int how_to_unfold()
{
    printf("exit the static inline!!\n");
    return 123;
}

#define how_to_unfold1() \
{\
    printf("exit the define!!\n"); \
}

#endif
