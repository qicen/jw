#include <stdio.h>
#include <unistd.h>

#include <sys/types.h>

int main()
{
    int child_pid;

    child_pid = vfork();
    if (child_pid < 0) {
        printf("vfork failed\n");
    } else if (child_pid == 0) {
        sleep(3);
        printf("I am child!\n");
    } else {
        printf("I am parent!\n");
    }
    return 0;
}
