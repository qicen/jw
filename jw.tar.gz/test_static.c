#include <stdio.h>

int test1()
{
	static int aaa=1;
    aaa+=10;
	printf("aaa in test1 %d, %d\n", &aaa, aaa);
	return 0;
}

int test2()
{
	static int aaa=2;
	aaa+=100;
	printf("aaa in test2 %d, %d\n", &aaa, aaa);
	return 0;
}

void main()
{
	test1();
	test2();
	aaa+=1000;
	printf("aaa in main %d, %d\n", &aaa, aaa);
}
