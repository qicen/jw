#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

#define REPORT_ "report_"
int main()
{
#if 0
    int fd1, fd2;

    fd1 = open("foo.txt", O_RDONLY, 0);
    fd2 = open("bar.txt", O_RDONLY, 0);

    close(fd2);

    fd2 = open("baz.txt", O_RDONLY, 0);
    printf("fd2 = %d\n", fd2);
    exit(0);
#endif
    FILE *fp;
    char *a;
    fp = fopen("foo.txt", "w");
    if (!fp) {
        printf("open foo.txt failed!!!\n");
        return -1;
    }
    fprintf(fp, "%d", 1);
    fclose(fp);

    fp = fopen("foo.txt", "r");
    printf("the value is %d\n", fgetc(fp));
    fclose(fp);
    a = REPORT_"aaaaaaaaaaaaaa";
    printf("%s\n", a);
    return 0;
}
