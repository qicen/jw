#include "unistd.h"
#include "stdio.h"

#include <linux/spinlock.h>

spinlock_t lock_0;
spinlock_t *lock_0_p = &lock_0;

int
main(void)
{
    spin_lock_init(lock_0_p);
    spin_lock(lock_0_p);
    printf("1111111111\n");
    sleep(100);
    spin_unlock(lock_0_p);
    return 0;
}
