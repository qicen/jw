#include <netdb.h>
#include <sys/socket.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    char **pp;
    struct in_addr ip;
    struct hostent *host;

    if (argc != 2) {
        fprintf(stderr, "%s <address or hostname>", argv[0]);
        exit(-1);
    }

try_again:
    if (inet_aton(argv[1], &ip) != 0) {
        fprintf(stdout, "type in address. loading......\n");
        host = gethostbyaddr(&ip, sizeof(ip), AF_INET);
    } else {
        fprintf(stdout, "type in hostname. loading ......\n");
        host = gethostbyname(argv[1]);
    }

    if (!host) {
        switch(h_errno){
            case HOST_NOT_FOUND:
                fprintf(stdout, "error HOST_NOT_FOUND\n");
                exit(-2);
            case NO_DATA:
                fprintf(stdout, "error NO_DATA\n");
                exit(-3);
            case NO_RECOVERY:
                fprintf(stdout, "error NO_RECOVERY\n");
                exit(-4);
            case TRY_AGAIN:
                fprintf(stdout, "warning, try again:\n");
                goto try_again;
            default:
                fprintf(stdout, "unknow error %d\n", h_errno);
                exit(-5);
        }
    }
    fprintf(stdout, "offical name: %s\n", host->h_name);
    fprintf(stdout, "alias:\n");
    for(pp=host->h_aliases; *pp!=NULL;pp++) {
        fprintf(stdout, "\t%s\n", *pp);
    }
    fprintf(stdout, "addresses:\n");
    for(pp=host->h_addr_list;*pp!=NULL;pp++) {
        ip.s_addr = *((uint32_t *)*pp);
        fprintf(stdout, "\t%s\n", inet_ntoa(ip));
    }
    exit(0);
}
