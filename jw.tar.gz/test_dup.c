#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main()
{
	int fd;
	int old_stdout;
	FILE *stream;
	FILE *stream1;

	remove("test_dup.file");
	fd = open("test_dup.file", O_CREAT|O_RDWR, 0644);
	if (fd == -1) {
		printf("failed to open test_dup.file");
		return -1;
	}
	old_stdout = dup(1);
	dup2(fd, 1);

	//fprintf(fd, "in the file: fd = %d, old_stdout = %d\n", fd, old_stdout);
	//setlinebuf(stdout);
	//setbuffer(stdout, buffer, 1);
	printf("fd = %d, old_stdout = %d, stdout = %llu\n", fd, old_stdout, (long long)stdout);
	stream = fdopen(fd, "w+");
	stream1 = fopen("test_dup1.file", "a");
	close(fd);
	fflush(stdout);
	close(1);
	dup2(old_stdout, 1);
	printf("write the fd info to the file\n");
	return 0;
}
