#include <stdio.h>
#include <stdlib.h>

int
main(void)
{
    char a[8] = {
    71,79,79,68,66,89,69
    };

    printf("%s\n", a);
    return 0;
}
