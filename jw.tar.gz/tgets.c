#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

char rcv_msg[2048];

void sig_handler(int sig)
{
    switch (sig) {
        case SIGALRM:
            printf("timeout!! please type something:\n");
            alarm(5);
            break;
        case SIGINT:
            printf("Bye\n");
            exit(0);
        default:
            printf("Unknown sig %d\n", sig);
            break;
    }
}

int main()
{
    int i;
#if 0
    struct sigaction action, old_action;
    
    action.as_handler = sig_handler;
    sigemptyset(&action.as_mask);
    action.sa_flags = 0;
#endif
    if (signal(SIGALRM, sig_handler)!=0) {
        printf("install alarm failed!\n");
        exit(-1);
    }
    if (signal(SIGINT, sig_handler)!=0) {
        printf("install ctrl-c failed!\n");
        exit(-2);
    }

    printf("Hello, please type something:\n");
    alarm(5);
    while(1) {
        memset(rcv_msg, 0, sizeof(rcv_msg));
        i = read(0, (void *)rcv_msg, sizeof(rcv_msg));
        if (i>0) {
            printf("your input: %s\n", rcv_msg);
            printf("please type something:\n");
            alarm(5);
        } else {
            printf("error i %d\n", i);
        }
    }
    return 0;
}
