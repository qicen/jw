#include <stdio.h>
#include <signal.h>

#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include <errno.h>
#include <string.h>


#if 0
/* defined in <arpa/inet.h> */
struct in_addr {
    uint s_addr;
};
/*
 *  * bind function, return 0 if ok, -1 for error.
 *   */
struct sockaddr_in {
    unsigned char   sin_len;
    unsigned char   sin_family;
    ushort sin_port;                /* udp/tcp port */
    struct in_addr sin_addr;        /* ip addr */
    char sin_zero[8];               /* store mac addresses in case of raw pack sockets*/
};
#endif


int sig_cnt = 0;

extern void setup_sighandler(int sig, void (*sighandler)(int));
static void
sig_handler(int sig)
{
    sigset_t mask;
    unsigned long mask_l;
    sigprocmask(SIG_BLOCK, NULL, &mask);
    mask_l = *((unsigned long *)&mask);
    printf("got sig %d/%d, mask 0x%x\n", sig, sigismember(&mask, sig), mask_l);
    sig_cnt++;
    setup_sighandler(SIGUSR2, SIG_IGN);
    sigprocmask(SIG_UNBLOCK, &mask, NULL);
    kill(getpid(), SIGUSR2);
    sigprocmask(SIG_SETMASK, &mask, NULL);
    setup_sighandler(SIGUSR2, sig_handler);
}

void
setup_sighandler(int sig, void (*sighandler)(int))
{
#if 1
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_flags = 0;
    sa.sa_flags |= SA_RESTART | SA_NODEFER;
    sa.sa_handler = sighandler;
    sigemptyset(&(sa.sa_mask));
    sigaddset(&(sa.sa_mask), sig);
    sigaction(sig, &sa, NULL);
#else
    signal(SIGUSR2, sig_handler);
#endif
}

int
main()
{
    int sock;
    int rc;
    struct sockaddr_in sock_addr;
    char *hostname = "127.0.0.1";

    setup_sighandler(SIGUSR2, sig_handler);

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        printf("socket failed:  %d/%s\n", errno, strerror(errno));
        return -1;
    } else {
        printf("socket %d created.\n", sock);
    }

    //sock_addr.sin_len = 4;
    sock_addr.sin_family = AF_INET;
    sock_addr.sin_port = 5555;
    sock_addr.sin_addr.s_addr = htonl(inet_addr(hostname));

    rc = connect(sock, (const struct sockaddr *)&sock_addr, sizeof(sock_addr));
    if (rc != 0) {
        printf("connect failed %d: %d/%s\n", rc, errno, strerror(errno));
        return -2;
    } else {
        printf("connect successfully\n");
        close(sock);
    }

    return 0;
}
