#include <stdio.h>
#include <string.h>

#define HPL_MSGID_AAAAA 10

#define STR_2_INT(_str) (int)(HPL_MSGID_##_str)

int
main(int argc, char argv[])
{
    char *aaa = "AAAAA";
    int a;

    a = STR_2_INT(aaa);
    printf("%d\n", a); 
    return 0;
}
