#include "stdio.h"

typedef struct {
    union {
        char aaa[4];
        int  i;
    } n;
} byte_order_ele;

extern int is_big_endian(void);
int 
is_big_endian()
{
    byte_order_ele ele;
    ele.n.i = 0x12345678;
    if (ele.n.aaa[0] == 0x78) {
        return 0;
    } else {
        return 1;
    }
}

int
main()
{
    int i;
    i = is_big_endian();
    if(i) {
        printf("the machine is big endian\n");
    } else {
        printf("the macheine is little endian\n");
    }
}
