#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

jmp_buf buf;
int error1 = 1;
int error2 = 1;

void bar(void);

void foo(void)
{
    printf("enter foo\n");
    if (error1) {
        error1 = 0;
        longjmp(buf, 1);
        printf("reach here????\n");
    }
        
    bar();
}

void bar(void)
{
    printf("enter bar\n");
    if (error2)
        longjmp(buf, 2);
}

static void sig_handler(int sig)
{
    siglongjmp(buf, 1);
}

#if JUST_JMP
int main()
{
    int rc;

    rc = setjmp(buf);
    printf("11111 rc = %d\n", rc);

    if (rc == 0) {
        foo();
    } else if (rc == 1) {
        printf("2222222\n");
        foo();
    } else if (rc == 2) {
        printf("333333333\n");
    } else {
        printf("Unknown error\n");
    }
    
    exit(0);
}
#else
int main()
{
    if(signal(SIGINT, sig_handler) != 0) {
        printf("install signal failed\n");
        return -1;
    }

    if (!sigsetjmp(buf, 1)) {
        printf("starting process .\n");
    } else {
        printf("restarting ...\n");
    }

    while(1) {
        sleep(1);
        printf("processing...........\n");
    }
    return 0;
}
#endif
