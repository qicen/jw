#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <errno.h>
#include <string.h>

int main(int argc, char *argv[])
{
    char *file_name = argv[1];
    int fd = 0;
    int rc = 0;
    struct stat st_buf;
    int file_size = 0;
    char *file_bytes;

    fd = open(file_name, O_RDWR);
    if (fd < 0) {
        printf("open file %s failed at %d:%s\n", file_name, errno, strerror(errno));
        return -1;
    }
    rc = fstat(fd, &st_buf);
    if (rc < 0) {
        printf("get file %s stat failed at %d:%s\n", file_name, errno, strerror(errno));
        close(fd);
        return -2;
    }
    file_size = st_buf.st_size;
    file_bytes = mmap(0, file_size, PROT_READ, MAP_PRIVATE, fd, 0);
    if (file_bytes < 0) {
        printf("map file %s failed at %d:%s\n", file_name, errno, strerror(errno));
        close(fd);
        return -3;
    }
    printf("\n\n%s\n", file_bytes);
    close(fd);
    return 0;
}
