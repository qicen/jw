#######
License
#######

Copyright (c) 2001-2015 Alexandre Cassen.

This document is released under the terms of the GNU General Public Licence.
You can redistribute it and/or modify it under the terms of the GNU General
Public Licence as published by the Free Software Foundation; either version
2 of the Licence, or (at your option) any later version.
