#ifndef __ASPF_POLICY_CLI_H__
#define __ASPF_POLICY_CLI_H__

extern void aspf_policy_cli_init(void);

#endif
