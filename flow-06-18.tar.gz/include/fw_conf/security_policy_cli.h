#ifndef __SECURITY_POLICY_CLI_H__
#define __SECURITY_POLICY_CLI_H__

extern void security_policy_cli_init(void);

#endif
