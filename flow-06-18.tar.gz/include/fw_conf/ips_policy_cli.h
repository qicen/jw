#ifndef __IPS_POLICY_CLI_H__
#define __IPS_POLICY_CLI_H__

extern void ips_policy_cli_init(void);

#endif
