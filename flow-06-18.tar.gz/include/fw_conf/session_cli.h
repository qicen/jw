#ifndef __SESSION_CLI_H__
#define __SESSION_CLI_H__

extern void session_cli_init(void);

#endif
