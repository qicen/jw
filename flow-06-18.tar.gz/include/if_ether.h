#ifndef IF_ETHER_H
#define IF_ETHER_H

#define ETH_DATA_LEN	1500		/* Max. octets in payload	 */

#endif

