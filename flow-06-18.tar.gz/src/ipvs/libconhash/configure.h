
/* Copyright (C) 2010. sparkling.liang@hotmail.com. All rights reserved. */

#ifndef __CONFIGURE_H_
#define __CONFIGURE_H_
#include "dpdk.h"

typedef unsigned int u_int;
typedef unsigned char u_char;
typedef long util_long;

#endif /* end __CONFIGURE_H_ */
