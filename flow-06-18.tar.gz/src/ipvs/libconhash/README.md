References:
-----------
a, Consistent hashing library comes from <a href="http://www.codeproject.com/Articles/56138/Consistent-hashing">libconhash</a>

License:
--------
Under GUN License
